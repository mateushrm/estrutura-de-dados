#include <stdio.h>
#include <locale.h>
#include "livro.h"

int main(void){
  setlocale(LC_ALL,"Portuguese");
  plivro livro=NULL;
  int n;
  scanf("%d", &n);
  livro = livro_alocar(n);
  livro_dados(n, livro);
  livro_exibe(n, livro);

  return 0;
}
