#include "livro.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

void flush_in(){
  int ch;
  while((ch=fgetc(stdin))!= EOF && ch!= '\n'){
  }
}

typedef struct livro
{
char nome[50];
char isbn[21];
float preco;
float avaliacao;
char editora[50];
}tlivro, *plivro;

plivro livro_alocar(int n)
{
  if(n>0)
  return (plivro)malloc(n*sizeof(tlivro));
  if(n<0 || n==0)
  printf("[Nenhum registro lido]");
  return NULL;
}

void livro_dados(int qntddLivro, tlivro *livro)
{
  int i;
  for(i=0; i<qntddLivro; i++)
  {
  scanf(" %[^\n]", livro[i].nome);
  flush_in();
  
  scanf(" %[^\n]", livro[i].isbn);
  flush_in();
  
  scanf("%f", &livro[i].preco);
  flush_in();
  
  scanf("%f", &livro[i].avaliacao);
  flush_in();
    
  scanf(" %[^\n]", livro[i].editora);
  flush_in();
  }
}

void livro_exibe(int qntddLivro,tlivro *livro)
{
  int i;
  for(i=0; i<qntddLivro; i++)
  {
  printf("[Registro %d]\n", i+1);
  printf("Nome: %s\n", livro[i].nome);
  printf("ISBN: %s\n", livro[i].isbn);
  printf("Preço: R$ %.2f\n", livro[i].preco);
  printf("Avaliação: %.1f\n", livro[i].avaliacao);
  printf("Editora: %s\n", livro[i].editora);
  }
}