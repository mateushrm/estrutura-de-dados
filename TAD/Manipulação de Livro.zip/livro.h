#ifndef __livro__h
#define __livro__h

typedef struct livro tlivro, *plivro;
plivro livro_alocar(int n);
void livro_dados(int qntddLivro, tlivro *livro);
void livro_exibe(int qntddLivro,tlivro *livro);

#endif // __livro__h

