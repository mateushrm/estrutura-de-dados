#ifndef __pilha__h
#define __pilha__h

typedef struct no{
  char dado;
  struct no *prox;
}No;

typedef struct pilha{
  No *topo;
  int tam;
}Pilha;

void pilha_criar();
void pilha_empilhar(Pilha *p, char dd);
No *pilha_desempilhar(Pilha *p);
No *pilha_limpar(Pilha *p);
void pilha_exibir(Pilha *p);

#endif