#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pilha.h"

int main() {
    No *remover;
    Pilha a;
    char opcao[4];
    char inserir;

  pilha_criar(&a);
  
    do {
        scanf("%s%*c", opcao);
        
        if(strcmp("-s", opcao) == 0)
            pilha_exibir(&a);
      
        if(strcmp("-c", opcao) == 0)
            pilha_limpar(&a);
      
        if(strcmp("-i", opcao) == 0) {
            scanf("%s", &inserir);
            pilha_empilhar(&a, inserir);
        } 
      
      if(strcmp("-r", opcao) == 0){
            remover = pilha_desempilhar(&a);
            if(remover)
              free(remover);
          }
    }while(strcmp("-s", opcao) != 0);

    return 0;
}