#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

void pilha_criar(Pilha *p){
  p->topo = NULL;
  p->tam = 0;
}

void pilha_empilhar(Pilha *p, char dd){
  No *novo= malloc(sizeof(No));

  if(novo){
    novo->dado = dd;
    novo->prox = p->topo;
    p->topo = novo;
    p->tam++;
  } else {
    printf("Erro ao alocar");
  }
}

No *pilha_desempilhar(Pilha *p){
  if(p->topo){
    No *remover = p->topo;
    p->topo = remover->prox;
    p->tam--;
    return remover;
  } else {
    printf("Pilha vazia");
  }
}

No *pilha_limpar(Pilha *p){
  while(p->tam != 0){
    pilha_desempilhar(p);
  }
}

void pilha_exibir(Pilha *p){
  No *aux = p->topo;
  
  if(p->tam == 0){
    printf("Pilha vazia");
  } else {
    while(aux){
    char vet[p->tam];
      for(int i = 0; i < p->tam; i++) {
          vet[i] = aux->dado;
          aux = aux->prox;
        }
      for(int i = p->tam - 1; i >= 0; i--){
          printf("%c", vet[i]);
        }
      } 
   }
    
}

