#include <stdio.h>
#include <stdlib.h>
#include "listaSimples.h"

struct no{
  int dado;
  struct no *prox;
};

struct lista{
  No *ini;
  int tam;
};

Lista *lista_criar(){
  Lista* l = (Lista*) malloc (sizeof(Lista));
    if (l == NULL) {
        return NULL;
    }
    l->tam = 0;
    l->ini = NULL;
    return l;
}

void flush_in(){
  int ch;
  while((ch=fgetc(stdin))!= EOF && ch!= '\n'){
  }
}

void lista_adicionar(Lista *l, int dd){
  No *novo= malloc(sizeof(No));
  
  if(novo){
    novo->dado = dd;
    novo->prox = l->ini;
    l->ini = novo;
    l->tam++;
  } else {
    printf("Erro ao alocar\n");
  }
}

void lista_adicionar_meio(Lista *l, int dd, int ref){
    ref--;
    if (ref == 0) 
        lista_adicionar(l, dd);
  
    No *novo = (No*) malloc (sizeof(No));
    novo->dado = dd;
    novo->prox = NULL;
    No* aux2 = l->ini;
    for (int i = 1; i < ref; i++) {
        aux2 = aux2->prox;
    }
    novo->prox = aux2->prox;
    aux2->prox = novo;
    l->tam++;
}

void buscar_maiores(Lista *l, int dd){
    int cont = 0;
    No *aux = l->ini;
    do {
        if (aux->dado > dd) {
            cont++;
        }
        aux = aux->prox;
    } while ((aux != NULL) && (aux != l->ini));
    printf("%d\n", cont);
}

No *lista_remover(Lista *l, int dd){
    No *aux, *remover = NULL;

    if(l->ini){
        if(l->ini->dado == dd){
            remover = l->ini;
            l->ini = remover->prox;
            l->tam--;
        }
        else{
            aux = l->ini;
            while(aux->prox && aux->prox->dado != dd)
                aux = aux->prox;
            if(aux->prox){
                remover = aux->prox;
                aux->prox = remover->prox;
                l->tam--;
            }
        }
    }

    return remover;
}

int lista_remover_ini(Lista* l){
    No* aux = NULL;
    if (l->tam == 1) {
        aux = l->ini;
        l->ini = NULL;
        free(aux);
    } else {
        aux = l->ini;
        l->ini = aux->prox;
        free(aux);
    }
    l->tam--;
    return 0;
}

int *lista_limpar(Lista *l){

  if (l->tam != 0) {
        while (l->tam != 0) {
            lista_remover_ini(l);
        }
    }
  return 0;
}

void lista_exibe_tam(Lista *l){
  printf("%d\n", l->tam);
}

int lista_maior(Lista *l){
    int maior = l->ini->dado;
    No *aux = l->ini;
    do {
        if (maior < aux->dado) {
            maior = aux->dado;
        }
        aux = aux->prox;
    } while ((aux != NULL) && (aux != l->ini));
    return maior;
}

void lista_exibe_prim(Lista *l){
  No *aux= l->ini;
  printf("%d\n", aux->dado);  
}

void lista_exibe_ult(Lista *l){
  No *aux = l->ini;

  while(aux->prox){
    aux = aux->prox;
  } printf("%d\n", aux->dado);
}  

void lista_exibir(Lista *l){
    if(l->tam == 0){
      printf("Lista vazia");
    } else{
    No *aux = l->ini;
    do {
        printf("%d ", aux->dado);
        aux = aux->prox;
    } while ((aux != NULL) && (aux != l->ini));
  }
}

int lista_destruir(Lista* l) {
    if (l->tam == 0) {
        free(l);  
    } else {
        lista_limpar(l);
    }
    return 0;
}
