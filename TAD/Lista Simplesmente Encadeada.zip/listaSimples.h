#ifndef __fila__h
#define __fila__h

typedef struct no No;

typedef struct lista Lista;

Lista* lista_criar();
void flush_in();
void lista_adicionar(Lista *l, int dd);
void lista_adicionar_meio(Lista *l, int dd, int ref);
void buscar_maiores(Lista *l, int dd);
No *lista_remover(Lista *l, int dd);
int lista_remover_ini(Lista* l);
int *lista_limpar(Lista *l);
void lista_exibe_tam(Lista *l);
int lista_maior(Lista *l);
void lista_exibe_prim(Lista *l);
void lista_exibe_ult(Lista *l);
void lista_exibir(Lista *l);
int lista_destruir(Lista* l);

#endif