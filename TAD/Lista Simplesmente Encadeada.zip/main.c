#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "listaSimples.h"

int main() {
    No *remover;
    Lista *a = lista_criar();
    char opcao[4];
    int dado = 0, ref = 0, maior = 0;
  
    do {
        scanf("%s%*c", opcao);	
        
        if(strcmp("-s", opcao) == 0)
            lista_exibir(a);
      
        if(strcmp("-c", opcao) == 0)
            lista_limpar(a);
      
        if(!(strcmp("-a", opcao))) {
            scanf("%d", &dado);
		        getchar();
          if ((dado == 1) || (dado == 42) || (dado == 45) || (dado == 67)) {
                scanf("%d", &ref);
                lista_adicionar_meio(a, dado, ref);
            } else {
                lista_adicionar(a, dado);
            }
        }
  
      if(strcmp("-r", opcao) == 0){
            scanf("%d", &dado);
		        getchar();
            remover = lista_remover(a, dado);
            if(remover)
              free(remover);
          }
      
      if(strcmp("-m", opcao) == 0){
        maior = lista_maior(a);
        printf("%d\n", maior);
      }

      if(strcmp("-sl", opcao) == 0){
        lista_exibe_ult(a);
      }
      
      if(strcmp("-sf", opcao) == 0){
        lista_exibe_prim(a);
      }
      
      if(strcmp("-ss", opcao) == 0){
        lista_exibe_tam(a);
      }
      
      if(strcmp("-sg", opcao) == 0){
        scanf("%d", &ref);
        getchar();
        buscar_maiores(a, ref);
      }
      
    }while(strcmp("-s", opcao) != 0);

    lista_destruir(a);
  
    return 0;
}