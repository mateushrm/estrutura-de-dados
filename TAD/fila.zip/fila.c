#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

void fila_criar(Fila *f){
  f->prim = NULL;
  f->fim = NULL;
  f->tam = 0;
}

void fila_adicionar(Fila *f, int dd){
  No *novo= malloc(sizeof(No));

  if(novo){
    novo->dado = dd;
    novo->prox = NULL;
    if(f->prim == NULL){
    f->prim = novo;
    f->fim = novo;
    f->tam++;
  } else {
    f->fim->prox = novo;
    f->fim = novo;
    f->tam++;
  }
  } else {
    printf("Erro ao alocar");
  }
}

No *fila_remover(Fila *f){
  No *remover = NULL;
  
  if(f->prim){
    remover = f->prim;
    f->prim = remover->prox;
    f->tam--;
    return remover;
  } else {
    printf("Fila vazia");
  }
}

No *fila_limpar(Fila *f){
  while(f->prim != NULL){
    fila_remover(f);
  }
}

void fila_exibir(Fila *f){
  No *aux = f->prim;
  int i;
  
  if(f->tam == 0){
    printf("Fila vazia");
  } else {
    for(i = 0; i < f->tam; i++){
      printf("%d", aux->dado);
      if(aux->prox != NULL)
        printf(", ");
      
      aux = aux->prox;
    } 
   }
    
}