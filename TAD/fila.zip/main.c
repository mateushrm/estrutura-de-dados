#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fila.h"


int main() {
    No *remover;
    Fila a;
    char opcao[4];
    int inserir;

  fila_criar(&a);
  
    do {
        scanf("%s%*c", opcao);
        
        if(strcmp("-s", opcao) == 0)
            fila_exibir(&a);
      
        if(strcmp("-c", opcao) == 0)
            fila_limpar(&a);
      
        if(strcmp("-i", opcao) == 0) {
            scanf("%d", &inserir);
            fila_adicionar(&a, inserir);
        } 
      
      if(strcmp("-r", opcao) == 0){
            remover = fila_remover(&a);
            if(remover)
              free(remover);
          }
    }while(strcmp("-s", opcao) != 0);

    return 0;
}