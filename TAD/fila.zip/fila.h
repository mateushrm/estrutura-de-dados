#ifndef __fila__h
#define __fila__h

typedef struct no{
  char dado;
  struct no *prox;
}No;

typedef struct fila{
  No *prim;
  No *fim;
  int tam;
}Fila;

void fila_criar();
void fila_adicionar(Fila *f, int dd);
No *fila_remover(Fila *f);
No *fila_limpar(Fila *f);
void fila_exibir(Fila *f);

#endif